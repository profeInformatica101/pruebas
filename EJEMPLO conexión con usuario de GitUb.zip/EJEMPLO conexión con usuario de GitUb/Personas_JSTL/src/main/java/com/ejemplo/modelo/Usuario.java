package com.ejemplo.modelo;

import java.io.Serializable;

public class Usuario implements Serializable{
	private static final long serialVersionUID = 1L;

    private int id;
    private String nombreDeUsuario;
    private String contraseña;
    private Persona persona;
    
    
   
	public Usuario() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombreDeUsuario() {
		return nombreDeUsuario;
	}
	public void setNombreDeUsuario(String nombreDeUsuario) {
		this.nombreDeUsuario = nombreDeUsuario;
	}
	public String getContraseña() {
		return contraseña;
	}
	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}
	public Persona getPersona() {
		return persona;
	}
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
    
}
