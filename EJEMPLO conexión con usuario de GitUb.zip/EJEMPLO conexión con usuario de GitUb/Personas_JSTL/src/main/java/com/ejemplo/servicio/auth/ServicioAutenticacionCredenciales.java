package com.ejemplo.servicio.auth;

import com.ejemplo.modelo.Usuario;

public interface ServicioAutenticacionCredenciales {
    Usuario autenticarConCredenciales(String usuario, String contraseña);
}
