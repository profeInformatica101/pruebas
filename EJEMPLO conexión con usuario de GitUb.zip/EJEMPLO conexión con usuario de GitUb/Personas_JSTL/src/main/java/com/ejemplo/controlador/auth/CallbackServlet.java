package com.ejemplo.controlador.auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class CallbackServlet
 */
@WebServlet("/callback")
public class CallbackServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        
        // Maneja el 'code' para obtener un token de acceso.
        
        // Redirige al usuario a la página deseada después de completar el login.
        response.sendRedirect("/Personas_JSTL/listarPersonas.jsp");
    }
}
