package com.ejemplo.controlador.auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.ejemplo.servicio.ConfigLoader;
import com.ejemplo.servicio.auth.impl.GitHubAppAuthenticationService;

/**
 * Servlet implementation class GitHubServlet
 */
public class GitHubServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    private ConfigLoader configLoader;
    private GitHubAppAuthenticationService authService;

    @Override
    public void init() throws ServletException {
        configLoader = ConfigLoader.getInstance();
        authService = GitHubAppAuthenticationService.getInstance();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	   // Obtener la URL de autorización de GitHub
        String clientId = configLoader.getClientId();
        String redirectUri = configLoader.getRedirectUri();

        String githubAuthUrl = "https://github.com/login/oauth/authorize"
                + "?client_id=" + clientId
                + "&redirect_uri=" + redirectUri;

        // Redirigir al usuario a la URL de autorización de GitHub
        response.sendRedirect(githubAuthUrl);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}