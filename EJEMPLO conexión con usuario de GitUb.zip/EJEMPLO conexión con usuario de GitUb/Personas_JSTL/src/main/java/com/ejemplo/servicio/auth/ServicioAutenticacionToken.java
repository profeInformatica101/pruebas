package com.ejemplo.servicio.auth;

import com.ejemplo.modelo.Usuario;

public interface ServicioAutenticacionToken {
    Usuario autenticarConToken(String token);
}
