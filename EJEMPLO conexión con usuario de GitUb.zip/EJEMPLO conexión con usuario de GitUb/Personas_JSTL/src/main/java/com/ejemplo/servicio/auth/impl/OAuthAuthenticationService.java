package com.ejemplo.servicio.auth.impl;

public class OAuthAuthenticationService {

}
