package com.ejemplo.filtro;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;



import com.ejemplo.servicio.ConfigLoader;

/**
 * Servlet Filter implementation class AuthenticationFilter
 */
@WebFilter("/ListarPersona")
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        System.out.println("AuthenticationFilter.doFilter");
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        HttpSession session = httpRequest.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            String clientId = ConfigLoader.getInstance().getClientId();
            String redirectUri = ConfigLoader.getInstance().getRedirectUri();
            String githubAuthUrl = null;

            try {
                githubAuthUrl = "https://github.com/login/oauth/authorize"
                        + "?client_id=" + clientId
                        + "&redirect_uri=" + URLEncoder.encode(redirectUri, StandardCharsets.UTF_8.name());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace(); // Considera cambiar por logging apropiado
                httpResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Encoding Error");
                return;
            }

            httpResponse.setStatus(HttpServletResponse.SC_SEE_OTHER); // 303 See Other
            httpResponse.setHeader("Location", githubAuthUrl);
        } else {
            chain.doFilter(request, response);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {
    }

    @Override
    public void destroy() {
    }
}
