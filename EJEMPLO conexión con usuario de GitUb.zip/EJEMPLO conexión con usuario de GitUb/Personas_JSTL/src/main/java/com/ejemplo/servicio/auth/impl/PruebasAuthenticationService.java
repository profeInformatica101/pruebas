package com.ejemplo.servicio.auth.impl;

import com.ejemplo.modelo.Usuario;
import com.ejemplo.servicio.auth.ServicioAutenticacionCredenciales;

public class PruebasAuthenticationService  implements ServicioAutenticacionCredenciales{

	@Override
	public Usuario autenticarConCredenciales(String usuario, String contraseña) {
		// TODO Auto-generated method stub
		return null;
	}

}
