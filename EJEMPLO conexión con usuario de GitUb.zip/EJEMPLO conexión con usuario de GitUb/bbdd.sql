-- Verifica si la base de datos existe, si no la crea
CREATE DATABASE IF NOT EXISTS mi_bbdd_ejemplo;
USE mi_bbdd_ejemplo;

-- Crea la tabla personas si no existe
CREATE TABLE IF NOT EXISTS personas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    apellido VARCHAR(255) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    lugar_nacimiento VARCHAR(255) NOT NULL
);

-- Inserta valores de prueba con nombres inspirados en personajes de Dragon Ball
INSERT INTO personas (nombre, apellido, fecha_nacimiento, lugar_nacimiento) VALUES 
('Goku', 'Saiyajin', '1984-04-16', 'Vegeta'),
('Vegeta', 'Principe', '1980-05-12', 'Vegeta'),
('Bulma', 'Brief', '1985-03-15', 'Tierra'),
('Gohan', 'Saiyajin', '1996-09-14', 'Tierra'),
('Trunks', 'Brief', '1997-01-21', 'Tierra'),
('Krillin', 'Monje', '1983-11-04', 'Tierra'),
('Piccolo', 'Namekusei', '1978-10-09', 'Namek'),
('Freezer', 'Tirano', '1970-07-01', 'Universo 7'),
('Cell', 'Androide', '1992-06-25', 'Laboratorio'),
('Majin', 'Boo', '1995-02-08', 'Tierra'),
('Roshi', 'Maestro', '1940-03-02', 'Kame House'),
('Yamcha', 'Luchador', '1982-08-12', 'Tierra'),
('Tien', 'Shinhan', '1981-01-28', 'Tierra'),
('Chiaotzu', 'Clown', '1984-05-17', 'Tierra'),
('Videl', 'Satán', '1997-11-03', 'Ciudad Satán'),
('Bardock', 'Saiyajin', '1950-12-02', 'Vegeta'),
('Broly', 'Legendario', '1986-02-14', 'Planeta Vampa'),
('Caulifla', 'Saiyajin', '1998-04-29', 'Universo 6'),
('Kale', 'Saiyajin', '1999-08-06', 'Universo 6'),
('Jiren', 'Justiciero', '1975-09-15', 'Universo 11'),
('Hit', 'Asesino', '1965-07-20', 'Universo 6'),
('Zamasu', 'Kaioshin', '1990-03-31', 'Universo 10'),
('Cabeza', 'Gran', '1960-01-11', 'Namek'),
('Raditz', 'Saiyajin', '1983-06-02', 'Vegeta'),
('Nappa', 'Calvo', '1969-12-23', 'Vegeta'),
('Whis', 'Ángel', '0001-01-01', 'Reino de los Ángeles'),
('Beerus', 'Dios', '0001-01-02', 'Universo 7'),
('Shenlong', 'Dragón', '0001-01-03', 'Tierra'),
('Dende', 'Guardián', '1994-10-12', 'Tierra'),
('Pan', 'Saiyajin', '2005-05-05', 'Tierra');


