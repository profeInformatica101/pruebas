package com.ejemplo.controlador;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;
import com.ejemplo.modelo.Persona;
import com.ejemplo.servicio.bbdd.PersonaServicio;
/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	PersonaServicio servicio = PersonaServicioImplMock.obtenerInstancia();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		List<Persona> personas = servicio.getAllPersonas();
		request.setAttribute("PERSONAS", personas);
		System.out.println("||-->HomeServlet.doGet atributo=PERSONAS:"+request.getAttribute("PERSONAS")); // Imprimir en consola
		RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/home.jsp");
		dispatcher.forward(request, response);	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
