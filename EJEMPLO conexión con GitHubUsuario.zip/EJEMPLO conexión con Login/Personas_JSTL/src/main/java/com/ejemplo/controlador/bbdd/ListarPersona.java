package com.ejemplo.controlador.bbdd;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

import com.ejemplo.modelo.Persona;
import com.ejemplo.servicio.bbdd.PersonaServicio;
import com.ejemplo.servicio.bbdd.PersonaServicioImpl;
import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;

/**
 * Servlet implementation class ListarPersona
 */
public class ListarPersona extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	PersonaServicio servicio = PersonaServicioImplMock.obtenerInstancia();
	//PersonaServicio servicio = PersonaServicioImpl.obtenerInstancia();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListarPersona() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ListarPersona.doGET");

		List<Persona> personas = servicio.getAllPersonas();
		request.setAttribute("PERSONAS", personas);
		
	 RequestDispatcher dispatcher = request.getRequestDispatcher("JSP/home.jsp");
	 dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("ListarPersona.doPost");
		
		
		boolean filtrarMenores = "true".equals(request.getParameter("filter"));
		
		List<Persona> personas = servicio.getAllPersonas();
		if(filtrarMenores) {
			personas = personas.stream().filter(p-> {
				Calendar c = Calendar.getInstance();
				c.setTime(p.getFechaNacimiento());
				int year = c.get(Calendar.YEAR);
				int currentYear = Calendar.getInstance().get(Calendar.YEAR);
				return (currentYear - year) <= 18;

			}).collect(Collectors.toList());
		}
		
		
		request.setAttribute("PERSONAS", personas);
		RequestDispatcher dispacher = request.getRequestDispatcher("JSP/home.jsp");
		dispacher.forward(request, response);
	}

}
