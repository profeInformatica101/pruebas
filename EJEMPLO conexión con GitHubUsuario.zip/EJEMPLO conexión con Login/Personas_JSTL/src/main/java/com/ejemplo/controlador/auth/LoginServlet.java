package com.ejemplo.controlador.auth;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.ejemplo.modelo.Persona;
import com.ejemplo.modelo.UsuarioCredenciales;
import com.ejemplo.servicio.auth.ServicioAutenticacionCredenciales;
import com.ejemplo.servicio.auth.impl.PruebasAuthenticationService;
import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    ServicioAutenticacionCredenciales personaServicio = PruebasAuthenticationService.obtenerInstancia();

    public LoginServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String usuario = request.getParameter("username");
        String clave = request.getParameter("password");
        System.out.println("LoginServlet.doPost  usuario:" + usuario + ", clave: " + clave);

        try {
        	//usuarioAutenticado OBJETO de USUARIO
            UsuarioCredenciales usuarioAutenticado = personaServicio.autenticarConCredenciales(usuario, clave);
            
            if (usuarioAutenticado == null) {
                throw new Exception("Autenticación fallida");
            }

            System.out.println(usuarioAutenticado.toString());
            HttpSession session = request.getSession();
            
            session.setAttribute("usuario", usuarioAutenticado);
            session.setAttribute("tipo", "UsuarioCredenciales");
            response.sendRedirect(request.getContextPath() + "/home");

        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
            e.printStackTrace();
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}
