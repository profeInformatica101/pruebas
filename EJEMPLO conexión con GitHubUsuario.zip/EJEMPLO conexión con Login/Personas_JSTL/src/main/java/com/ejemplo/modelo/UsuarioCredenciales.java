package com.ejemplo.modelo;

import java.io.Serializable;

public class UsuarioCredenciales implements Serializable{
	private static final long serialVersionUID = 1L;
	

    private long id;
    private String usuario;
    private String contraseña;
    private Persona persona;
    private String token;
    
	public UsuarioCredenciales() {
		super();
	}

	public UsuarioCredenciales(long id, String usuario, String contraseña, Persona persona) {
		this.id = id;
		this.usuario = usuario;
		this.contraseña = contraseña;
		this.persona = persona;
	}

	public long getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContraseña() {
		return contraseña;
	}
	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}
	public Persona getPersona() {
		return persona;
	}
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		if(usuario !=null) {
			return "UsuarioCredenciales [id=" + id + ", nombreDeUsuario=" + usuario + ", contraseña=" + contraseña
					+ ", persona=" + persona + "]";
		}else {
			return "UsuarioCredenciales GitHUB [nombre: "+  persona.getNombre() + ", apellido: " + persona.getApellido()+ "]";
		}

	}
}
