package com.ejemplo.servicio.auth.impl;

import java.util.HashMap;
import java.util.Map;

import javax.naming.AuthenticationException;

import com.ejemplo.modelo.UsuarioCredenciales;
import com.ejemplo.servicio.auth.ServicioAutenticacionCredenciales;

import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;

public class PruebasAuthenticationService implements ServicioAutenticacionCredenciales {
	private static PruebasAuthenticationService instancia;
	private final Map<Long, UsuarioCredenciales> usuarioCredenciales = new HashMap<>();

	public static synchronized PruebasAuthenticationService obtenerInstancia() {
		if (instancia == null) {
			instancia = new PruebasAuthenticationService();
		}
		return instancia;
	}

	public PruebasAuthenticationService() {
	
		
		try {
			usuarioCredenciales.put(1L, new UsuarioCredenciales(1L, "admin", "admin",
					PersonaServicioImplMock.obtenerInstancia().readPersona(1L)));
			usuarioCredenciales.put(2L, new UsuarioCredenciales(2L, "admin2", "admin2",
					PersonaServicioImplMock.obtenerInstancia().readPersona(2L)));
			
		} catch (Exception e) {

			System.out.println(e.toString());
		}

	}

	@Override
	public UsuarioCredenciales autenticarConCredenciales(String usuario, String contraseña) {

		UsuarioCredenciales usuarioAutenticado = null;
		try {
			usuarioAutenticado = usuarioCredenciales.values().stream()
					.filter(u -> u.getUsuario().equals(usuario) && u.getContraseña().equals(contraseña)).findFirst()
					.orElseThrow(() -> new AuthenticationException("UsuarioCredenciales o contraseña incorrectos."));
		} catch (AuthenticationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.toString());
		}
		return usuarioAutenticado;
	}

}
