package com.ejemplo.servicio.auth;

import com.ejemplo.modelo.UsuarioCredenciales;

public interface ServicioAutenticacionCredenciales {
    UsuarioCredenciales autenticarConCredenciales(String usuario, String contraseña);
}
