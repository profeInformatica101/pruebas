package com.ejemplo.controlador.bbdd;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ejemplo.servicio.bbdd.PersonaServicio;
import com.ejemplo.servicio.bbdd.PersonaServicioImpl;
import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;

/**
 * Servlet implementation class EliminarPersona
 */
public class EliminarPersona extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PersonaServicio servicio = PersonaServicioImplMock.obtenerInstancia();
	//PersonaServicio servicio = PersonaServicioImpl.obtenerInstancia();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EliminarPersona() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String id = request.getParameter("id");
		
		
		System.out.println("EliminarPersona.doPost id: "+id);

		try {

			if (servicio.deletePersona(Long.parseLong(id))) {
				response.sendRedirect("JSP/mensajes/exito.jsp"); // redirigir a una página de éxito o donde prefieras
			} else {
				response.sendRedirect("JSP/mensajes/error.jsp"); // redirigir a una página de error o donde prefieras
			}

		} catch (Exception e) {
			System.out.println(e.toString());
			response.sendRedirect("JSP/mensajes/error.jsp"); // redirigir a una página de error o donde prefieras
		}
	}

}
