package com.ejemplo.controlador.bbdd;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ejemplo.modelo.Persona;
import com.ejemplo.servicio.bbdd.PersonaServicio;
import com.ejemplo.servicio.bbdd.PersonaServicioImplMock;

/**
 * Servlet implementation class CrearPersona
 */
public class CrearPersona extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	PersonaServicio servicio = PersonaServicioImplMock.obtenerInstancia();
	//PersonaServicio servicio = PersonaServicioImpl.obtenerInstancia();
	/**
     * @see HttpServlet#HttpServlet()
     */
    public CrearPersona() {
        super();
      
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("JSP/persona/crearPersona.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
          throws ServletException, IOException {
    	System.out.println("CrearPersona.doPost");
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String fechaNacimiento = request.getParameter("fechaNacimiento");
        String lugarNacimiento = request.getParameter("lugarNacimiento");
        
        try {
            Date fecha = new SimpleDateFormat("yyyy-MM-dd").parse(fechaNacimiento);
            Persona nuevaPersona = new Persona(nombre, apellido, fecha, lugarNacimiento); // 0L porque el ID será asignado por el servicio
            servicio.createPersona(nuevaPersona);
            response.sendRedirect("JSP/mensajes/exito.jsp"); // redirigir a una página de éxito o donde prefieras
        } catch(ParseException e) {
            e.printStackTrace();
            response.sendRedirect("JSP/mensajes/error.jsp"); // redirigir a una página de error o donde prefieras
        }
    }

}
