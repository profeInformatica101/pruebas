package com.swapi.models;


import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
public class Persona implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @SerializedName("id")
    private Integer id;

	@SerializedName("name")
    private String name;
    
    @SerializedName("height")
    private String height;
    
    @SerializedName("mass")
    private String mass;
    
    @SerializedName("hair_color")
    private String hairColor;
    
    @SerializedName("skin_color")
    private String skinColor;
    
    @SerializedName("eye_color")
    private String eyeColor;
    
    @SerializedName("birth_year")
    private String birthYear;
    
    @SerializedName("gender")
    private String gender;
    
    @SerializedName("homeworld")
    private String homeworldUrl;
    
    @SerializedName("films")
    private List<String> filmsUrls;
    
    @SerializedName("species")
    private List<String> speciesUrls;
    
    @SerializedName("vehicles")
    private List<String> vehiclesUrls;
    
    @SerializedName("starships")
    private List<String> starshipsUrls;

    
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getMass() {
		return mass;
	}

	public void setMass(String mass) {
		this.mass = mass;
	}

	public String getHairColor() {
		return hairColor;
	}

	public void setHairColor(String hairColor) {
		this.hairColor = hairColor;
	}

	public String getSkinColor() {
		return skinColor;
	}

	public void setSkinColor(String skinColor) {
		this.skinColor = skinColor;
	}

	public String getEyeColor() {
		return eyeColor;
	}

	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}

	public String getBirthYear() {
		return birthYear;
	}

	public void setBirthYear(String birthYear) {
		this.birthYear = birthYear;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHomeworldUrl() {
		return homeworldUrl;
	}

	public void setHomeworldUrl(String homeworldUrl) {
		this.homeworldUrl = homeworldUrl;
	}

	public List<String> getFilmsUrls() {
		return filmsUrls;
	}

	public void setFilmsUrls(List<String> filmsUrls) {
		this.filmsUrls = filmsUrls;
	}

	public List<String> getSpeciesUrls() {
		return speciesUrls;
	}

	public void setSpeciesUrls(List<String> speciesUrls) {
		this.speciesUrls = speciesUrls;
	}

	public List<String> getVehiclesUrls() {
		return vehiclesUrls;
	}

	public void setVehiclesUrls(List<String> vehiclesUrls) {
		this.vehiclesUrls = vehiclesUrls;
	}

	public List<String> getStarshipsUrls() {
		return starshipsUrls;
	}

	public void setStarshipsUrls(List<String> starshipsUrls) {
		this.starshipsUrls = starshipsUrls;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Persona(String name, String height, String mass, String hairColor, String skinColor, String eyeColor,
			String birthYear, String gender, String homeworldUrl, List<String> filmsUrls, List<String> speciesUrls,
			List<String> vehiclesUrls, List<String> starshipsUrls) {
		super();
		this.name = name;
		this.height = height;
		this.mass = mass;
		this.hairColor = hairColor;
		this.skinColor = skinColor;
		this.eyeColor = eyeColor;
		this.birthYear = birthYear;
		this.gender = gender;
		this.homeworldUrl = homeworldUrl;
		this.filmsUrls = filmsUrls;
		this.speciesUrls = speciesUrls;
		this.vehiclesUrls = vehiclesUrls;
		this.starshipsUrls = starshipsUrls;
	}
    
    
    
    
}