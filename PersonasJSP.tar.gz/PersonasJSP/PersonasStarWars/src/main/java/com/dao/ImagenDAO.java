package com.dao;


import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.SystemInfo;
public class ImagenDAO {
	
	public ImagenDAO() {
		  try {
	  	        // Cargar el driver
	  	        Class.forName("com.mysql.cj.jdbc.Driver");
	  	    } catch (ClassNotFoundException e) {
	  	        e.printStackTrace();
	  	    }
	}
    
    public boolean guardarImagen(Integer id, String fileName, InputStream fileContent) {
    	System.out.println("guardarImagen: " + id + " "+ fileName );
        try (Connection con = DriverManager.getConnection(
                SystemInfo.getInstance().getUserKey("URL"),
                SystemInfo.getInstance().getUserKey("USUARIO"),
                SystemInfo.getInstance().getUserKey("CLAVE"));
             PreparedStatement pstmt = con.prepareStatement(
                     "INSERT INTO imagenes (id, nombre, imagen) VALUES (?, ?, ?)")) {
            
        	pstmt.setInt(1, id);
        	pstmt.setString(2, fileName);
            pstmt.setBlob(3, fileContent); // Nota que usamos setBlob aquí
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.toString());
            return false;
        }
    }

    public byte[] obtenerImagen(Integer id) {

    	  
        try (Connection con = DriverManager.getConnection(
                SystemInfo.getInstance().getUserKey("URL"),
                SystemInfo.getInstance().getUserKey("USUARIO"),
                SystemInfo.getInstance().getUserKey("CLAVE"));
             PreparedStatement pstmt = con.prepareStatement(
                     "SELECT imagen FROM imagenes WHERE id = ?")) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Blob blob = rs.getBlob("imagen");
                    return blob.getBytes(1, (int) blob.length());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
    public boolean existeImagen(Integer id) {
        try (Connection con = DriverManager.getConnection(
                SystemInfo.getInstance().getUserKey("URL"),
                SystemInfo.getInstance().getUserKey("USUARIO"),
                SystemInfo.getInstance().getUserKey("CLAVE"));
             PreparedStatement pstmt = con.prepareStatement(
                     "SELECT COUNT(*) FROM imagenes WHERE id = ?")) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // Devuelve true si hay al menos una imagen con el id dado
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Devuelve false si ocurre algún error o no se encuentra ninguna imagen
    }
    public boolean actualizarImagen(Integer id, String fileName, InputStream fileContent) {
        try (Connection con = DriverManager.getConnection(
                SystemInfo.getInstance().getUserKey("URL"),
                SystemInfo.getInstance().getUserKey("USUARIO"),
                SystemInfo.getInstance().getUserKey("CLAVE"))) {

            // Verificar si existe una imagen con el id dado
            if (!existeImagen(id)) {
                return false; // No existe una imagen con el id dado, no se puede actualizar
            }

            // Actualizar la imagen
            PreparedStatement pstmt = con.prepareStatement(
                    "UPDATE imagenes SET nombre = ?, imagen = ? WHERE id = ?");
            pstmt.setString(1, fileName);
            pstmt.setBlob(2, fileContent);
            pstmt.setInt(3, id);

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e.toString());
            return false;
        }
    }

}