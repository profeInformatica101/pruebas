package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import com.dao.ImagenDAO;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/upload")
@MultipartConfig(
		  location="/tmp", 
		  maxFileSize=20848820,    // 20MB
		  maxRequestSize=418018841, // 40MB
		  fileSizeThreshold=1048576 // 1MB
		)
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	  ImagenDAO imagenDAO = new ImagenDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */


@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        // Cargar el driver
        Class.forName("com.mysql.cj.jdbc.Driver");
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
        return;
    }
    
    try {
        String idStr = request.getParameter("personajeId");

        if (idStr != null) {
            Integer id = Integer.parseInt(idStr);
            Part filePart = request.getPart("file");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            InputStream fileContent = filePart.getInputStream();

            System.out.println("id: " + id + ", filePart: " + filePart.toString() + ", fileName: " + fileName);

            ImagenDAO imagenDAO = new ImagenDAO();
            
            // Verificar si existe una imagen con el id dado
            if (imagenDAO.existeImagen(id)) {
                // Existe una imagen, realiza la operación de actualización
                if (imagenDAO.actualizarImagen(id, fileName, fileContent)) {
                    response.sendRedirect(request.getContextPath() + "/index.jsp");
                } else {
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while updating the image.");
                }
            } else {
                // No existe una imagen con el id dado, realiza la operación de inserción
                if (imagenDAO.guardarImagen(id, fileName, fileContent)) {
                    response.sendRedirect(request.getContextPath() + "/index.jsp");
                } else {
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while saving the image.");
                }
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/error500.jsp");
        }

    } catch (Exception e) {
        e.printStackTrace();
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing the file.");
    }
}

}
