package com.servlet;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.dao.ImagenDAO;

/**
 * Servlet implementation class ImageServlet
 */
@WebServlet("/getImage")
public class ImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 ImagenDAO imagenDAO;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config) throws ServletException {

        // Store the ServletConfig object and log the initialization
        super.init(config);
        this.imagenDAO = new ImagenDAO(); // Inicializas tu DAO.
        
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        
        if(idStr != null) {

            Integer id = Integer.parseInt(idStr);
          
            byte[] imageData = imagenDAO.obtenerImagen(id);
            if(imageData != null) {
                response.setContentType("image/jpeg");
                response.getOutputStream().write(imageData);
            }
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
