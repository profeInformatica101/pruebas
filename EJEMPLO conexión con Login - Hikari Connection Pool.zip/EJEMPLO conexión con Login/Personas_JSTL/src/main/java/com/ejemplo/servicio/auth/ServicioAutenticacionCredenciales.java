package com.ejemplo.servicio.auth;

import com.ejemplo.modelo.BaseDatosUsuario;

public interface ServicioAutenticacionCredenciales {
    BaseDatosUsuario autenticarConCredenciales(String usuario, String contraseña);
}
