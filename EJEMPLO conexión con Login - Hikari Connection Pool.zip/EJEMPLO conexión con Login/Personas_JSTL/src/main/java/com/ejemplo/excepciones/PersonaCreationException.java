package com.ejemplo.excepciones;

public class PersonaCreationException extends Exception {

    private static final long serialVersionUID = 1L;

    public PersonaCreationException(String message) {
        super(message);
    }

    public PersonaCreationException(String message, Throwable cause) {
        super(message, cause);
    }
}