package com.ejemplo.controlador.auth;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Optional;


import com.ejemplo.modelo.BaseDatosUsuario;

import com.ejemplo.servicio.bbdd.BaseDatosUsuarioRepository;
import com.ejemplo.servicio.bbdd.DataSourceConfig;

import com.ejemplo.servicio.bbdd.impl.DatabaseConnectionPoolHikari;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private BaseDatosUsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            // Utilizar el método para crear la configuración y pasarla al repositorio.
            this.usuarioRepository = new BaseDatosUsuarioRepository(createDataSourceConfig());
        } catch (Exception e) {
            throw new ServletException("Error initializing PersonaRepository", e);
        }
    }


    private DataSourceConfig createDataSourceConfig() {
    	return new DatabaseConnectionPoolHikari();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String usuario = request.getParameter("username");
        String clave = request.getParameter("password");
        
        try {
            Optional<BaseDatosUsuario> usuarioOpt = usuarioRepository.findUsuarioByCredentials(usuario, clave);
            if (usuarioOpt.isPresent()) {
                BaseDatosUsuario usuarioAutenticado = usuarioOpt.get();

                // Lógica adicional si es necesario, por ejemplo, registrar la hora de inicio de sesión, etc.

                HttpSession session = request.getSession();
                session.setAttribute("usuario", usuarioAutenticado);  // Guardar el usuario en la sesión
                session.setAttribute("tipo", "BaseDatosUsuario"); // Puede almacenar el tipo de usuario si es relevante
                
                // Redirigir al usuario a una página de inicio o a una dashboard, por ejemplo:
                response.sendRedirect(request.getContextPath() + "/home");
            } else {
                throw new Exception("Autenticación fallida");
            }

        } catch (Exception e) {
            e.printStackTrace();  // Usar un logger en producción.
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}