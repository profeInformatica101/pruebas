package com.ejemplo.controlador.bbdd;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.ejemplo.modelo.Persona;
import com.ejemplo.servicio.bbdd.DataSourceConfig;
import com.ejemplo.servicio.bbdd.PersonaRepository;
import com.ejemplo.servicio.bbdd.impl.DatabaseConnectionPoolHikari;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/crearPersona")
public class CrearPersona extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private PersonaRepository personaRepository;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            // Utilizar el método para crear la configuración y pasarla al repositorio.
            this.personaRepository = new PersonaRepository(createDataSourceConfig());
        } catch (Exception e) {
            throw new ServletException("Error initializing PersonaRepository", e);
        }
    }



	private DataSourceConfig createDataSourceConfig() {
		
		return new DatabaseConnectionPoolHikari();
	}



	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nombre = req.getParameter("nombre");
        String apellido = req.getParameter("apellido");
        String fechaNacimientoStr = req.getParameter("fecha_nacimiento");
        String lugarNacimiento = req.getParameter("lugar_nacimiento");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            Persona nuevaPersona = new Persona(
                    nombre,
                    apellido,
                    sdf.parse(fechaNacimientoStr),
                    lugarNacimiento
            );

            if (personaRepository.createPersona(nuevaPersona)) {
                resp.sendRedirect("exito.jsp");  // Redireccionar a una página de éxito
            } else {
                resp.sendRedirect("error.jsp");  // Redireccionar a una página de error
            }
        } catch (ParseException e) {
            e.printStackTrace();  // En un escenario real, es recomendable usar un logger
            resp.sendRedirect("error.jsp");  // Redireccionar a una página de error
        }
    }
}