package com.ejemplo.servicio.bbdd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import javax.sql.DataSource;

import com.ejemplo.modelo.BaseDatosUsuario;

public class BaseDatosUsuarioRepository {
    private final DataSource dataSource;

    public BaseDatosUsuarioRepository(DataSourceConfig dataSourceConfig) {
        this.dataSource = dataSourceConfig.configureDataSource();
    }

    public Optional<BaseDatosUsuario> findUsuarioByCredentials(String usuario, String contrasena) {
        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, contrasena);  // Atención: en la práctica, nunca almacenar y comparar contraseñas en texto claro!

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new BaseDatosUsuario(
                            rs.getLong("id"),
                            rs.getString("usuario"),
                            rs.getString("contrasena"),
                            rs.getString("nombre"),
                            rs.getString("apellido")
                    ));
                }
            }
        }  catch (SQLException e) {
            throw new RuntimeException("Error obtener usuario", e);
        }
        return Optional.empty();
    }
}