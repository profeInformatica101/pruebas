package com.ejemplo.controlador.bbdd;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ejemplo.modelo.Persona;
import com.ejemplo.servicio.bbdd.DataSourceConfig;
import com.ejemplo.servicio.bbdd.PersonaRepository;

import com.ejemplo.servicio.bbdd.impl.DatabaseConnectionPoolHikari;

/**
 * Servlet implementation class ModificarPersona
 */
public class ModificarPersona extends HttpServlet {
	private static final long serialVersionUID = 1L;
	   private PersonaRepository personaRepository;
	   
	   @Override
	    public void init() throws ServletException {
	        super.init();
	        try {
	            // Utilizar el método para crear la configuración y pasarla al repositorio.
	            this.personaRepository = new PersonaRepository(createDataSourceConfig());
	        } catch (Exception e) {
	            throw new ServletException("Error initializing PersonaRepository", e);
	        }
	    }



		private DataSourceConfig createDataSourceConfig() {
			
			return new DatabaseConnectionPoolHikari();
		}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
   
    /***
     * MODIFICA LOS DATOS
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    	System.out.println("ModificarPersona.doPost");
        try {
            Long id = Long.parseLong(request.getParameter("id"));
            String nombre = request.getParameter("nombre");
            String apellido = request.getParameter("apellido");
            String fechaNacimiento = request.getParameter("fechaNacimiento");
            String lugarNacimiento = request.getParameter("lugarNacimiento");
            Persona nuevaPersona;
           
            Date fecha = null;
            
            try {
                fecha = new SimpleDateFormat("yyyy-MM-dd").parse(fechaNacimiento);
               
            } catch(ParseException e) {
                e.printStackTrace();
                response.sendRedirect("JSP/mensajes/error.jsp");
            }
            nuevaPersona = new Persona(id, nombre, apellido, fecha, lugarNacimiento);
            System.out.println(nuevaPersona.toString());
            
            
            boolean actualizado = personaRepository.updatePersona(nuevaPersona);
            
            
            if (!actualizado) {
                // Error al actualizar; manejar error
                response.sendRedirect("JSP/mensajes/error.jsp"); // Cambiar a tu página de error
                return;
            }
            
            response.sendRedirect("JSP/mensajes/exito.jsp"); // Cambiar a tu página de éxito o listado

        } catch (NumberFormatException e) {
            // ID inválido; manejar error
            response.sendRedirect("JSP/mensajes/error.jsp"); // Cambiar a tu página de error
        }
    }
    /***
     * RELLENA LOS DATOS
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Puedes usar este método para prellenar el formulario antes de modificar
    	System.out.println("ModificarPersona.doGet");
        try {
            Long id = Long.parseLong(request.getParameter("id"));
            Persona persona =   personaRepository.readPersona(id);
            
            if (persona == null) {
                // Persona no encontrada; manejar error
                response.sendRedirect("mensajes/error.jsp"); // Cambiar a tu página de error
                return;
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fechaNacimientoStr = sdf.format(persona.getFechaNacimiento());
            request.setAttribute("fechaNacimiento", fechaNacimientoStr);
        	request.setAttribute("persona", persona);
    		RequestDispatcher dispacher = request.getRequestDispatcher("JSP/persona/editarPersona.jsp");
    		dispacher.forward(request, response);


        } catch (NumberFormatException e) {
            // ID inválido; manejar error
            response.sendRedirect("mensajes/error.jsp"); // Cambiar a tu página de error
        }
    }

}
