package com.ejemplo.controlador.bbdd;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.ejemplo.servicio.bbdd.DataSourceConfig;
import com.ejemplo.servicio.bbdd.PersonaRepository;
import com.ejemplo.servicio.bbdd.impl.DatabaseConnectionPoolHikari;


/**
 * Servlet implementation class EliminarPersona
 */
public class EliminarPersona extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private PersonaRepository personaRepository;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EliminarPersona() {
		super();
	}
	@Override
    public void init() throws ServletException {
        super.init();
        try {
            // Utilizar el método para crear la configuración y pasarla al repositorio.
            this.personaRepository = new PersonaRepository(createDataSourceConfig());
        } catch (Exception e) {
            throw new ServletException("Error initializing PersonaRepository", e);
        }
    }



	private DataSourceConfig createDataSourceConfig() {
		
		return new DatabaseConnectionPoolHikari();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String id = request.getParameter("id");
		
		
		System.out.println("EliminarPersona.doPost id: "+id);

		try {

			if (personaRepository.deletePersona(Long.parseLong(id))){
				response.sendRedirect("JSP/mensajes/exito.jsp"); // redirigir a una página de éxito o donde prefieras
			} else {
				response.sendRedirect("JSP/mensajes/error.jsp"); // redirigir a una página de error o donde prefieras
			}

		} catch (Exception e) {
			System.out.println(e.toString());
			response.sendRedirect("JSP/mensajes/error.jsp"); // redirigir a una página de error o donde prefieras
		}
	}

}
