package com.ejemplo.servicio.bbdd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.ejemplo.modelo.Persona;

public class PersonaRepository {
    private final DataSource dataSource;

    public PersonaRepository(DataSourceConfig dataSourceConfig) {
        this.dataSource = dataSourceConfig.configureDataSource();

    }

    public boolean createPersona(Persona persona) {
        String sql = "INSERT INTO personas (nombre, apellido, fecha_nacimiento, lugar_nacimiento) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, persona.getNombre());
            statement.setString(2, persona.getApellido());
            statement.setDate(3, new java.sql.Date(persona.getFechaNacimiento().getTime()));
            statement.setString(4, persona.getLugarNacimiento());
            int rowsInserted = statement.executeUpdate();
            
            return rowsInserted > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error crear persona", e);
        }
    }

    public List<Persona> getAllPersonas() {
        List<Persona> result = new ArrayList<>();
        String sql = "SELECT * FROM personas";
        
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Persona persona = new Persona(
                        rs.getLong("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getDate("fecha_nacimiento"),
                        rs.getString("lugar_nacimiento")
                );
            
                result.add(persona);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error obtener personas", e);
        }
        return result;
    }

    public Persona readPersona(Long id) {
        String sql = "SELECT * FROM personas WHERE id = ?";
        
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setLong(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return new Persona(
                            rs.getLong("id"),
                            rs.getString("nombre"),
                            rs.getString("apellido"),
                            rs.getDate("fecha_nacimiento"),
                            rs.getString("lugar_nacimiento")
                    );
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error leer persona", e);
        }
    }
    public boolean updatePersona(Persona persona) {
        String sql = "UPDATE personas SET nombre = ?, apellido = ?, fecha_nacimiento = ?, lugar_nacimiento = ? WHERE id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, persona.getNombre());
            statement.setString(2, persona.getApellido());
            statement.setDate(3, new java.sql.Date(persona.getFechaNacimiento().getTime()));
            statement.setString(4, persona.getLugarNacimiento());
            statement.setLong(5, persona.getId());
            
            int rowsUpdated = statement.executeUpdate();

            return rowsUpdated > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error modificar persona", e);
        }
    }

    public boolean deletePersona(Long id) {
        String sql = "DELETE FROM personas WHERE id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setLong(1, id);
            
            int rowsDeleted = statement.executeUpdate();

            return rowsDeleted > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error borrar persona", e);
        }
    }
}