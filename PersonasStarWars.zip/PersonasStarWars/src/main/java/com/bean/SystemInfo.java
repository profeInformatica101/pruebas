package com.bean;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

public class SystemInfo {
	
    // Única instancia de la clase SystemInfo.
    private static final SystemInfo instance = new SystemInfo();

    // Mapa para almacenar las claves del usuario.
    private final Map<String, String> userKeys = new HashMap<>();
    
 // Constructor privado para evitar instanciación externa.
    private SystemInfo() { 
    	
    	
    }

    // Método público y estático para obtener la única instancia de la clase.
    public static SystemInfo getInstance() {
    	instance.storeUserKey("URL","jdbc:mysql://localhost:3306/mi_bbdd_proyecto");
    	instance.storeUserKey("USUARIO","root");
    	instance.storeUserKey("CLAVE","aza770AZE");
    	return instance;
    }
    // Método para guardar las claves del usuario.
    public void storeUserKey(String username, String key) {
        userKeys.put(username, key);
    }

    // Método para recuperar las claves del usuario.
    public String getUserKey(String username) {
        return userKeys.get(username);
    }

    // Método para obtener el nombre del sistema operativo.
    public String getOperatingSystemName() {
        return System.getProperty("os.name");
    }

    // Método para obtener la versión del sistema operativo.
    public String getOperatingSystemVersion() {
        return System.getProperty("os.version");
    }

    // Método para obtener la arquitectura del sistema operativo.
    public String getOperatingSystemArch() {
        return System.getProperty("os.arch");
    }

    // Método para obtener el nombre del usuario actual.
    public String getCurrentUsername() {
        return System.getProperty("user.name");
    }

    // Método para obtener el directorio del usuario.
    public String getUserDirectory() {
        return System.getProperty("user.home");
    }

    // Método para obtener el directorio de trabajo actual.
    public String getWorkingDirectory() {
        return System.getProperty("user.dir");
    }

    // Método para obtener la dirección IP del host local y el nombre del host.
    public String getHostInfo() {
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            return "Nombre del Host: " + inetAddress.getHostName() + ", Dirección IP: " + inetAddress.getHostAddress();
        } catch (UnknownHostException e) {
            return "No se pudo obtener la información del host";
        }
    }

    // Método principal para probar la clase SystemInfo.
    public static void main(String[] args) {
        SystemInfo systemInfo = new SystemInfo();

        // Guardar una clave de usuario.
        systemInfo.storeUserKey("JohnDoe", "MySecretKey");

        // Mostrar información del sistema.
        System.out.println("Sistema Operativo: " + systemInfo.getOperatingSystemName());
        System.out.println("Versión del Sistema Operativo: " + systemInfo.getOperatingSystemVersion());
        System.out.println("Arquitectura del Sistema Operativo: " + systemInfo.getOperatingSystemArch());
        System.out.println("Usuario Actual: " + systemInfo.getCurrentUsername());
        System.out.println("Directorio de Usuario: " + systemInfo.getUserDirectory());
        System.out.println("Directorio de Trabajo Actual: " + systemInfo.getWorkingDirectory());
        System.out.println("Información del Host: " + systemInfo.getHostInfo());

        // Recuperar y mostrar la clave del usuario.
        String userKey = systemInfo.getUserKey("JohnDoe");
        System.out.println("Clave de JohnDoe: " + userKey);
    }
}