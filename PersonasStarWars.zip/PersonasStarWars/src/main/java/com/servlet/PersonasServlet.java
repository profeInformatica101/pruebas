package com.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Paths;
import java.util.Base64;

import com.dao.ImagenDAO;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.swapi.models.Persona;

@WebServlet("/personas")
public class PersonasServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ImagenDAO imagenDAO; // Declaras la variable para tu DAO.
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PersonasServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    public void init(ServletConfig config) throws ServletException {

        // Store the ServletConfig object and log the initialization
        super.init(config);
        this.imagenDAO = new ImagenDAO(); // Inicializas tu DAO.
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	 HttpSession session = request.getSession();
    	 Integer personajeId;
    	try {
    		 personajeId = Integer.parseInt(session.getAttribute("personajeId").toString()) ;
		} catch (Exception e) {
			personajeId = 1;
		}
    		

    	 try {
    		 String accion = request.getParameter("accion");
    		 System.out.println("accion:"+accion);
    		

    	        if ("adelante".equals(accion) && personajeId < Integer.MAX_VALUE) {
    	            personajeId++;
    	            session.setAttribute("personajeId", personajeId);
    	        } else if ("atras".equals(accion) && personajeId > 1) {
    	            personajeId--;
    	            session.setAttribute("personajeId", personajeId);
    	        }
    	        System.out.println("personajeId:"+personajeId);
            
    	    String url = "https://swapi.dev/api/people/" + personajeId + "/?format=json";            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("GET");
            
            // Conecta y obtiene la respuesta
            con.connect();
            int responseCode = con.getResponseCode();
            
            if(responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();
                while((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();
                
                // Imprimir el contenido recibido
                System.out.println(content.toString());
                
                // Parsear el contenido recibido como JSON
                Gson gson = new Gson();
                try {
                    Persona person = gson.fromJson(content.toString(), Persona.class);
                    person.setId(personajeId);
                 
                 // Obtiene la imagen como array de bytes y la convierte a Base64.
                    byte[] imagenBytes;
                    try {
                        imagenBytes = imagenDAO.obtenerImagen(personajeId);
                    } catch (Exception e) {
                        imagenBytes = null;
                    }
                    
                    String imagenSrc;
                    if(imagenBytes != null) {
                        String imagenBase64 = Base64.getEncoder().encodeToString(imagenBytes);
                        imagenSrc = "data:image/jpeg;base64," + imagenBase64;
                    } else {
                        imagenSrc = "https://cdn.pixabay.com/photo/2017/11/10/04/47/user-2935373_960_720.png";
                    }
                    
                    System.out.println("Nombre:"+ person.getName());
                    System.out.println("imagenSrc:"+imagenSrc);
                    
                    request.setAttribute("imagenSrc", imagenSrc); // Añades la imagen como un atributo a la solicitud.
                    request.setAttribute("persona", person);
                    
                    
                    // Pasar el objeto person a la vista o hacer algo con él.
                } catch (JsonSyntaxException e) {
                    e.printStackTrace();
                    // Enviar a la página de error si el parseo falla
                    response.sendRedirect("error.jsp");
                }
            }
            // Reenviar la solicitud al JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
 
         
    	 }catch (Exception e) {
    		 response.sendRedirect("error500.jsp");
		}
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("doPost");
    	doGet(request, response);
    }

    

}

    	 


