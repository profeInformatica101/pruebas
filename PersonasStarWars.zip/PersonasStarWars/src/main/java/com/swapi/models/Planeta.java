package com.swapi.models;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;
import lombok.Data;


@Data
public class Planeta implements Serializable {

    private static final long serialVersionUID = 1L;

	@SerializedName("name")
    private String name;
    
    @SerializedName("rotation_period")
    private String rotationPeriod;
    
    @SerializedName("orbital_period")
    private String orbitalPeriod;
    
    @SerializedName("diameter")
    private String diameter;
    
    @SerializedName("climate")
    private String climate;
    
    @SerializedName("gravity")
    private String gravity;
    
    @SerializedName("terrain")
    private String terrain;
    
    @SerializedName("surface_water")
    private String surfaceWater;
    
    @SerializedName("population")
    private String population;
    
    @SerializedName("residents")
    private List<String> residentsUrls;
    
    @SerializedName("films")
    private List<String> filmsUrls;
    

}
